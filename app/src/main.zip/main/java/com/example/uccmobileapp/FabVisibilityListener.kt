package com.example.uccmobileapp

interface FabVisibilityListener {
    fun showFab()
    fun hideFab()
}